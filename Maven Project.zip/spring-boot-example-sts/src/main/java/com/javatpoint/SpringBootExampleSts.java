package com.javatpoint;
import org.springframework.boot.SpringApplication;  
import org.springframework.boot.autoconfigure.SpringBootApplication; 
@SpringBootApplication 			////similar to @Configuration @EnableAutoConfiguration @ComponentScan 
public class SpringBootExampleSts 
{
public static void main(String[] args)
{  
SpringApplication.run(SpringBootExampleSts.class, args);  
} 
}